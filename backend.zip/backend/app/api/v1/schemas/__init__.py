"""
Схемы данных для API v1.
"""

from .product import *
from .category import *
from .import_data import *
from .forecast import *
from .auth import *
from .common import * 