# 👨‍💻 Руководство разработчика

Техническое руководство для разработчиков системы управления товарными остатками.

## 📋 Содержание

- [Начало работы](#начало-работы)
- [Структура проекта](#структура-проекта)
- [Настройка среды разработки](#настройка-среды-разработки)
- [Backend разработка](#backend-разработка)
- [Frontend разработка](#frontend-разработка)
- [База данных](#база-данных)
- [API разработка](#api-разработка)
- [Тестирование](#тестирование)
- [Развертывание](#развертывание)
- [Стандарты кода](#стандарты-кода)

## 🚀 Начало работы

### Требования

- **Python 3.9+** для backend
- **Node.js 18+** для frontend
- **Docker & Docker Compose** для контейнеризации
- **PostgreSQL 13+** для базы данных
- **Redis 6+** для кэширования
- **Git** для версионирования

### Клонирование репозитория

```bash
git clone https://github.com/ColinsWey/inventory-system.git
cd inventory-system
```

### Быстрый запуск

```bash
# Копирование конфигурации
cp .env.example .env

# Запуск всех сервисов
docker-compose up -d

# Применение миграций
docker-compose exec backend alembic upgrade head

# Создание тестовых данных
docker-compose exec backend python scripts/create_test_data.py
```

## 📁 Структура проекта

```
inventory-system/
├── backend/                    # FastAPI backend
│   ├── app/
│   │   ├── api/               # API endpoints
│   │   │   ├── v1/            # API версия 1
│   │   │   │   ├── auth.py    # Аутентификация
│   │   │   │   ├── products.py # Товары
│   │   │   │   ├── forecasts.py # Прогнозы
│   │   │   │   └── reports.py  # Отчеты
│   │   │   └── deps.py        # Зависимости
│   │   ├── core/              # Основная конфигурация
│   │   │   ├── config.py      # Настройки
│   │   │   ├── security.py    # Безопасность
│   │   │   └── database.py    # База данных
│   │   ├── models/            # SQLAlchemy модели
│   │   │   ├── user.py        # Пользователи
│   │   │   ├── product.py     # Товары
│   │   │   ├── sale.py        # Продажи
│   │   │   └── forecast.py    # Прогнозы
│   │   ├── schemas/           # Pydantic схемы
│   │   │   ├── user.py        # Схемы пользователей
│   │   │   ├── product.py     # Схемы товаров
│   │   │   └── forecast.py    # Схемы прогнозов
│   │   ├── services/          # Бизнес логика
│   │   │   ├── auth.py        # Сервис аутентификации
│   │   │   ├── forecast.py    # Сервис прогнозирования
│   │   │   ├── import.py      # Сервис импорта
│   │   │   └── notification.py # Сервис уведомлений
│   │   ├── utils/             # Утилиты
│   │   │   ├── email.py       # Email утилиты
│   │   │   ├── cache.py       # Кэширование
│   │   │   └── validators.py  # Валидаторы
│   │   └── workers/           # Celery задачи
│   │       ├── forecast.py    # Задачи прогнозирования
│   │       └── import.py      # Задачи импорта
│   ├── alembic/               # Миграции БД
│   ├── scripts/               # Скрипты
│   ├── tests/                 # Тесты
│   ├── requirements.txt       # Зависимости
│   └── Dockerfile            # Docker образ
├── frontend/                  # React frontend
│   ├── public/               # Статические файлы
│   ├── src/
│   │   ├── components/       # React компоненты
│   │   │   ├── common/       # Общие компоненты
│   │   │   ├── auth/         # Компоненты авторизации
│   │   │   ├── products/     # Компоненты товаров
│   │   │   ├── forecasts/    # Компоненты прогнозов
│   │   │   └── reports/      # Компоненты отчетов
│   │   ├── pages/            # Страницы
│   │   │   ├── Dashboard.tsx # Главная страница
│   │   │   ├── Products.tsx  # Страница товаров
│   │   │   ├── Forecasts.tsx # Страница прогнозов
│   │   │   └── Reports.tsx   # Страница отчетов
│   │   ├── store/            # Redux store
│   │   │   ├── slices/       # Redux slices
│   │   │   └── api.ts        # RTK Query API
│   │   ├── services/         # API сервисы
│   │   ├── hooks/            # Пользовательские хуки
│   │   ├── utils/            # Утилиты
│   │   ├── types/            # TypeScript типы
│   │   └── styles/           # Стили
│   ├── package.json          # Зависимости
│   └── Dockerfile           # Docker образ
├── docs/                     # Документация
│   ├── INSTALL.md           # Установка
│   ├── USER_GUIDE.md        # Руководство пользователя
│   ├── API_DOCS.md          # API документация
│   ├── ARCHITECTURE.md      # Архитектура
│   ├── TROUBLESHOOTING.md   # Решение проблем
│   └── DEVELOPER_GUIDE.md   # Это руководство
├── tests/                   # Тесты
├── scripts/                 # Скрипты развертывания
├── docker-compose.yml       # Docker Compose
├── .env.example            # Пример конфигурации
└── README.md               # Основная документация
```

## ⚙️ Настройка среды разработки

### Backend разработка

#### 1. Создание виртуального окружения

```bash
cd backend
python -m venv venv

# Активация (Linux/Mac)
source venv/bin/activate

# Активация (Windows)
venv\Scripts\activate
```

#### 2. Установка зависимостей

```bash
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

#### 3. Настройка переменных окружения

```bash
# Создание .env файла
cp .env.example .env

# Редактирование настроек
nano .env
```

#### 4. Настройка базы данных

```bash
# Запуск PostgreSQL
docker run -d --name dev-postgres \
  -e POSTGRES_DB=inventory_dev \
  -e POSTGRES_USER=dev_user \
  -e POSTGRES_PASSWORD=dev_pass \
  -p 5432:5432 postgres:13

# Применение миграций
alembic upgrade head
```

#### 5. Запуск сервера разработки

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend разработка

#### 1. Установка зависимостей

```bash
cd frontend
npm install
```

#### 2. Настройка переменных окружения

```bash
# Создание .env файла
cp .env.example .env.local

# Редактирование настроек
nano .env.local
```

#### 3. Запуск сервера разработки

```bash
npm start
```

### Настройка IDE

#### VS Code

Рекомендуемые расширения:

```json
{
  "recommendations": [
    "ms-python.python",
    "ms-python.flake8",
    "ms-python.black-formatter",
    "bradlc.vscode-tailwindcss",
    "esbenp.prettier-vscode",
    "ms-vscode.vscode-typescript-next",
    "ms-vscode.vscode-json"
  ]
}
```

Настройки workspace:

```json
{
  "python.defaultInterpreterPath": "./backend/venv/bin/python",
  "python.formatting.provider": "black",
  "python.linting.enabled": true,
  "python.linting.flake8Enabled": true,
  "editor.formatOnSave": true,
  "typescript.preferences.importModuleSpecifier": "relative"
}
```

## 🐍 Backend разработка

### Архитектура

Backend построен на **FastAPI** с использованием:
- **SQLAlchemy** для ORM
- **Alembic** для миграций
- **Pydantic** для валидации
- **Celery** для фоновых задач
- **Redis** для кэширования

### Создание нового API endpoint

#### 1. Создание модели

```python
# app/models/example.py
from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.sql import func
from app.core.database import Base

class Example(Base):
    __tablename__ = "examples"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    description = Column(String(500))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
```

#### 2. Создание схем

```python
# app/schemas/example.py
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional

class ExampleBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=500)

class ExampleCreate(ExampleBase):
    pass

class ExampleUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=500)

class ExampleResponse(ExampleBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime]
    
    class Config:
        from_attributes = True
```

#### 3. Создание сервиса

```python
# app/services/example.py
from typing import List, Optional
from sqlalchemy.orm import Session
from app.models.example import Example
from app.schemas.example import ExampleCreate, ExampleUpdate

class ExampleService:
    def __init__(self, db: Session):
        self.db = db
    
    def create(self, example_data: ExampleCreate) -> Example:
        example = Example(**example_data.dict())
        self.db.add(example)
        self.db.commit()
        self.db.refresh(example)
        return example
    
    def get_by_id(self, example_id: int) -> Optional[Example]:
        return self.db.query(Example).filter(Example.id == example_id).first()
    
    def get_all(self, skip: int = 0, limit: int = 100) -> List[Example]:
        return self.db.query(Example).offset(skip).limit(limit).all()
    
    def update(self, example_id: int, example_data: ExampleUpdate) -> Optional[Example]:
        example = self.get_by_id(example_id)
        if not example:
            return None
        
        update_data = example_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(example, field, value)
        
        self.db.commit()
        self.db.refresh(example)
        return example
    
    def delete(self, example_id: int) -> bool:
        example = self.get_by_id(example_id)
        if not example:
            return False
        
        self.db.delete(example)
        self.db.commit()
        return True
```

#### 4. Создание API endpoint

```python
# app/api/v1/examples.py
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.services.example import ExampleService
from app.schemas.example import ExampleCreate, ExampleUpdate, ExampleResponse

router = APIRouter()

@router.post("/", response_model=ExampleResponse, status_code=status.HTTP_201_CREATED)
async def create_example(
    example_data: ExampleCreate,
    db: Session = Depends(get_db)
):
    service = ExampleService(db)
    return service.create(example_data)

@router.get("/{example_id}", response_model=ExampleResponse)
async def get_example(
    example_id: int,
    db: Session = Depends(get_db)
):
    service = ExampleService(db)
    example = service.get_by_id(example_id)
    if not example:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Example not found"
        )
    return example

@router.get("/", response_model=List[ExampleResponse])
async def get_examples(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    service = ExampleService(db)
    return service.get_all(skip=skip, limit=limit)

@router.put("/{example_id}", response_model=ExampleResponse)
async def update_example(
    example_id: int,
    example_data: ExampleUpdate,
    db: Session = Depends(get_db)
):
    service = ExampleService(db)
    example = service.update(example_id, example_data)
    if not example:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Example not found"
        )
    return example

@router.delete("/{example_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_example(
    example_id: int,
    db: Session = Depends(get_db)
):
    service = ExampleService(db)
    if not service.delete(example_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Example not found"
        )
```

#### 5. Регистрация роутера

```python
# app/api/v1/__init__.py
from fastapi import APIRouter
from app.api.v1 import auth, products, forecasts, examples

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["auth"])
api_router.include_router(products.router, prefix="/products", tags=["products"])
api_router.include_router(forecasts.router, prefix="/forecasts", tags=["forecasts"])
api_router.include_router(examples.router, prefix="/examples", tags=["examples"])
```

### Создание миграции

```bash
# Создание новой миграции
alembic revision --autogenerate -m "Add examples table"

# Применение миграции
alembic upgrade head

# Откат миграции
alembic downgrade -1
```

### Фоновые задачи (Celery)

```python
# app/workers/example.py
from celery import Celery
from app.core.config import settings

celery_app = Celery(
    "inventory_system",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL
)

@celery_app.task
def process_example_data(example_id: int):
    """Обработка данных примера в фоне"""
    # Логика обработки
    return {"status": "completed", "example_id": example_id}
```

## ⚛️ Frontend разработка

### Архитектура

Frontend построен на **React** с использованием:
- **TypeScript** для типизации
- **Redux Toolkit** для управления состоянием
- **RTK Query** для API запросов
- **Material-UI** для компонентов
- **React Router** для навигации

### Создание нового компонента

#### 1. Создание типов

```typescript
// src/types/example.ts
export interface Example {
  id: number;
  name: string;
  description?: string;
  created_at: string;
  updated_at?: string;
}

export interface ExampleCreate {
  name: string;
  description?: string;
}

export interface ExampleUpdate {
  name?: string;
  description?: string;
}
```

#### 2. Создание API slice

```typescript
// src/store/api/exampleApi.ts
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { Example, ExampleCreate, ExampleUpdate } from '../../types/example';

export const exampleApi = createApi({
  reducerPath: 'exampleApi',
  baseQuery: fetchBaseQuery({
    baseUrl: '/api/v1/examples',
    prepareHeaders: (headers, { getState }) => {
      const token = (getState() as any).auth.token;
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['Example'],
  endpoints: (builder) => ({
    getExamples: builder.query<Example[], { skip?: number; limit?: number }>({
      query: ({ skip = 0, limit = 100 } = {}) => 
        `?skip=${skip}&limit=${limit}`,
      providesTags: ['Example'],
    }),
    getExample: builder.query<Example, number>({
      query: (id) => `/${id}`,
      providesTags: (result, error, id) => [{ type: 'Example', id }],
    }),
    createExample: builder.mutation<Example, ExampleCreate>({
      query: (data) => ({
        url: '',
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ['Example'],
    }),
    updateExample: builder.mutation<Example, { id: number; data: ExampleUpdate }>({
      query: ({ id, data }) => ({
        url: `/${id}`,
        method: 'PUT',
        body: data,
      }),
      invalidatesTags: (result, error, { id }) => [{ type: 'Example', id }],
    }),
    deleteExample: builder.mutation<void, number>({
      query: (id) => ({
        url: `/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['Example'],
    }),
  }),
});

export const {
  useGetExamplesQuery,
  useGetExampleQuery,
  useCreateExampleMutation,
  useUpdateExampleMutation,
  useDeleteExampleMutation,
} = exampleApi;
```

#### 3. Создание компонента списка

```typescript
// src/components/examples/ExampleList.tsx
import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  CircularProgress,
} from '@mui/material';
import { Edit, Delete, Add } from '@mui/icons-material';
import { useGetExamplesQuery, useDeleteExampleMutation } from '../../store/api/exampleApi';
import { Example } from '../../types/example';
import ExampleForm from './ExampleForm';

const ExampleList: React.FC = () => {
  const [openForm, setOpenForm] = useState(false);
  const [editingExample, setEditingExample] = useState<Example | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const { data: examples, isLoading, error } = useGetExamplesQuery({});
  const [deleteExample, { isLoading: isDeleting }] = useDeleteExampleMutation();

  const handleEdit = (example: Example) => {
    setEditingExample(example);
    setOpenForm(true);
  };

  const handleDelete = async () => {
    if (deleteId) {
      try {
        await deleteExample(deleteId).unwrap();
        setDeleteId(null);
      } catch (error) {
        console.error('Failed to delete example:', error);
      }
    }
  };

  const handleCloseForm = () => {
    setOpenForm(false);
    setEditingExample(null);
  };

  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error">
        Ошибка загрузки данных
      </Alert>
    );
  }

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Примеры</Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => setOpenForm(true)}
        >
          Добавить пример
        </Button>
      </Box>

      <Box display="grid" gridTemplateColumns="repeat(auto-fill, minmax(300px, 1fr))" gap={2}>
        {examples?.map((example) => (
          <Card key={example.id}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                {example.name}
              </Typography>
              {example.description && (
                <Typography variant="body2" color="text.secondary" paragraph>
                  {example.description}
                </Typography>
              )}
              <Box display="flex" justifyContent="flex-end" gap={1}>
                <IconButton onClick={() => handleEdit(example)}>
                  <Edit />
                </IconButton>
                <IconButton onClick={() => setDeleteId(example.id)}>
                  <Delete />
                </IconButton>
              </Box>
            </CardContent>
          </Card>
        ))}
      </Box>

      {/* Форма создания/редактирования */}
      <Dialog open={openForm} onClose={handleCloseForm} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingExample ? 'Редактировать пример' : 'Создать пример'}
        </DialogTitle>
        <DialogContent>
          <ExampleForm
            example={editingExample}
            onSuccess={handleCloseForm}
          />
        </DialogContent>
      </Dialog>

      {/* Подтверждение удаления */}
      <Dialog open={!!deleteId} onClose={() => setDeleteId(null)}>
        <DialogTitle>Подтверждение удаления</DialogTitle>
        <DialogContent>
          <Typography>
            Вы уверены, что хотите удалить этот пример?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteId(null)}>Отмена</Button>
          <Button
            onClick={handleDelete}
            color="error"
            disabled={isDeleting}
          >
            {isDeleting ? <CircularProgress size={20} /> : 'Удалить'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ExampleList;
```

#### 4. Создание формы

```typescript
// src/components/examples/ExampleForm.tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import {
  Box,
  TextField,
  Button,
  Alert,
  CircularProgress,
} from '@mui/material';
import { useCreateExampleMutation, useUpdateExampleMutation } from '../../store/api/exampleApi';
import { Example, ExampleCreate } from '../../types/example';

interface ExampleFormProps {
  example?: Example | null;
  onSuccess: () => void;
}

const schema = yup.object({
  name: yup.string().required('Название обязательно').max(255, 'Максимум 255 символов'),
  description: yup.string().max(500, 'Максимум 500 символов'),
});

const ExampleForm: React.FC<ExampleFormProps> = ({ example, onSuccess }) => {
  const [createExample, { isLoading: isCreating, error: createError }] = useCreateExampleMutation();
  const [updateExample, { isLoading: isUpdating, error: updateError }] = useUpdateExampleMutation();

  const { control, handleSubmit, formState: { errors } } = useForm<ExampleCreate>({
    resolver: yupResolver(schema),
    defaultValues: {
      name: example?.name || '',
      description: example?.description || '',
    },
  });

  const onSubmit = async (data: ExampleCreate) => {
    try {
      if (example) {
        await updateExample({ id: example.id, data }).unwrap();
      } else {
        await createExample(data).unwrap();
      }
      onSuccess();
    } catch (error) {
      console.error('Failed to save example:', error);
    }
  };

  const isLoading = isCreating || isUpdating;
  const error = createError || updateError;

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)} sx={{ mt: 2 }}>
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          Ошибка сохранения данных
        </Alert>
      )}

      <Controller
        name="name"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            label="Название"
            fullWidth
            margin="normal"
            error={!!errors.name}
            helperText={errors.name?.message}
          />
        )}
      />

      <Controller
        name="description"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            label="Описание"
            fullWidth
            multiline
            rows={3}
            margin="normal"
            error={!!errors.description}
            helperText={errors.description?.message}
          />
        )}
      />

      <Box display="flex" justifyContent="flex-end" gap={2} mt={3}>
        <Button type="submit" variant="contained" disabled={isLoading}>
          {isLoading ? <CircularProgress size={20} /> : 'Сохранить'}
        </Button>
      </Box>
    </Box>
  );
};

export default ExampleForm;
```

### Создание страницы

```typescript
// src/pages/Examples.tsx
import React from 'react';
import { Container, Typography, Box } from '@mui/material';
import ExampleList from '../components/examples/ExampleList';

const Examples: React.FC = () => {
  return (
    <Container maxWidth="lg">
      <Box py={4}>
        <Typography variant="h3" component="h1" gutterBottom>
          Управление примерами
        </Typography>
        <ExampleList />
      </Box>
    </Container>
  );
};

export default Examples;
```

## 🗄️ База данных

### Создание миграций

```bash
# Создание новой миграции
alembic revision --autogenerate -m "Description of changes"

# Применение миграций
alembic upgrade head

# Откат на одну миграцию назад
alembic downgrade -1

# Просмотр истории миграций
alembic history

# Просмотр текущей версии
alembic current
```

### Работа с данными

#### Создание seed данных

```python
# scripts/create_seed_data.py
from sqlalchemy.orm import Session
from app.core.database import SessionLocal
from app.models.user import User
from app.models.category import Category
from app.models.product import Product
from app.core.security import get_password_hash

def create_seed_data():
    db = SessionLocal()
    
    try:
        # Создание администратора
        admin_user = User(
            username="admin",
            email="admin@example.com",
            password_hash=get_password_hash("admin"),
            role="admin"
        )
        db.add(admin_user)
        
        # Создание категорий
        categories = [
            Category(name="Электроника", description="Электронные устройства"),
            Category(name="Одежда", description="Одежда и аксессуары"),
            Category(name="Спорттовары", description="Товары для спорта"),
        ]
        
        for category in categories:
            db.add(category)
        
        db.commit()
        
        # Создание товаров
        products = [
            Product(
                name="iPhone 15 Pro",
                sku="IPHONE15PRO",
                category_id=1,
                price=89990,
                current_stock=25,
                min_stock=5,
                max_stock=100
            ),
            Product(
                name="Samsung Galaxy S24",
                sku="GALAXYS24",
                category_id=1,
                price=79990,
                current_stock=18,
                min_stock=3,
                max_stock=80
            ),
        ]
        
        for product in products:
            db.add(product)
        
        db.commit()
        print("Seed data created successfully!")
        
    except Exception as e:
        print(f"Error creating seed data: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    create_seed_data()
```

### Оптимизация запросов

#### Использование индексов

```python
# В модели
class Product(Base):
    __tablename__ = "products"
    
    id = Column(Integer, primary_key=True, index=True)
    sku = Column(String(50), unique=True, index=True)  # Индекс для быстрого поиска
    name = Column(String(255), index=True)  # Индекс для поиска по названию
    category_id = Column(Integer, ForeignKey("categories.id"), index=True)
```

#### Eager loading

```python
# Загрузка связанных данных
def get_products_with_categories(db: Session):
    return db.query(Product).options(joinedload(Product.category)).all()
```

## 🧪 Тестирование

### Backend тесты

#### Unit тесты

```python
# tests/unit/test_example_service.py
import pytest
from sqlalchemy.orm import Session
from app.services.example import ExampleService
from app.schemas.example import ExampleCreate, ExampleUpdate

class TestExampleService:
    def test_create_example(self, db: Session):
        service = ExampleService(db)
        example_data = ExampleCreate(name="Test Example", description="Test description")
        
        example = service.create(example_data)
        
        assert example.id is not None
        assert example.name == "Test Example"
        assert example.description == "Test description"
    
    def test_get_example_by_id(self, db: Session, sample_example):
        service = ExampleService(db)
        
        example = service.get_by_id(sample_example.id)
        
        assert example is not None
        assert example.id == sample_example.id
    
    def test_update_example(self, db: Session, sample_example):
        service = ExampleService(db)
        update_data = ExampleUpdate(name="Updated Name")
        
        updated_example = service.update(sample_example.id, update_data)
        
        assert updated_example.name == "Updated Name"
        assert updated_example.description == sample_example.description
```

#### Integration тесты

```python
# tests/integration/test_example_api.py
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

class TestExampleAPI:
    def test_create_example(self, auth_headers):
        example_data = {
            "name": "Test Example",
            "description": "Test description"
        }
        
        response = client.post("/api/v1/examples/", json=example_data, headers=auth_headers)
        
        assert response.status_code == 201
        data = response.json()
        assert data["name"] == "Test Example"
        assert data["id"] is not None
    
    def test_get_examples(self, auth_headers):
        response = client.get("/api/v1/examples/", headers=auth_headers)
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
```

### Frontend тесты

#### Unit тесты компонентов

```typescript
// src/components/examples/__tests__/ExampleList.test.tsx
import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import { configureStore } from '@reduxjs/toolkit';
import { exampleApi } from '../../../store/api/exampleApi';
import ExampleList from '../ExampleList';

const mockStore = configureStore({
  reducer: {
    [exampleApi.reducerPath]: exampleApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(exampleApi.middleware),
});

describe('ExampleList', () => {
  it('renders examples list', async () => {
    render(
      <Provider store={mockStore}>
        <ExampleList />
      </Provider>
    );

    await waitFor(() => {
      expect(screen.getByText('Примеры')).toBeInTheDocument();
    });
  });

  it('shows loading state', () => {
    render(
      <Provider store={mockStore}>
        <ExampleList />
      </Provider>
    );

    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });
});
```

## 🚀 Развертывание

### Development

```bash
# Запуск всех сервисов
docker-compose up -d

# Просмотр логов
docker-compose logs -f backend

# Перезапуск сервиса
docker-compose restart backend
```

### Production

#### 1. Подготовка сервера

```bash
# Установка Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Установка Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

#### 2. Настройка переменных окружения

```bash
# Создание production .env
cp .env.example .env.production

# Редактирование настроек
nano .env.production
```

#### 3. Развертывание

```bash
# Сборка и запуск
docker-compose -f docker-compose.prod.yml up -d --build

# Применение миграций
docker-compose -f docker-compose.prod.yml exec backend alembic upgrade head
```

### CI/CD Pipeline

```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Run tests
        run: |
          docker-compose -f docker-compose.test.yml up --abort-on-container-exit
          
  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Deploy to server
        uses: appleboy/ssh-action@v0.1.5
        with:
          host: ${{ secrets.HOST }}
          username: ${{ secrets.USERNAME }}
          key: ${{ secrets.SSH_KEY }}
          script: |
            cd /opt/inventory-system
            git pull origin main
            docker-compose -f docker-compose.prod.yml down
            docker-compose -f docker-compose.prod.yml up -d --build
            docker-compose -f docker-compose.prod.yml exec -T backend alembic upgrade head
```

## 📏 Стандарты кода

### Python (Backend)

#### Форматирование

```bash
# Black для форматирования
black app/ tests/

# isort для импортов
isort app/ tests/

# flake8 для линтинга
flake8 app/ tests/
```

#### Конфигурация

```ini
# pyproject.toml
[tool.black]
line-length = 88
target-version = ['py39']
include = '\.pyi?$'

[tool.isort]
profile = "black"
multi_line_output = 3

[tool.flake8]
max-line-length = 88
extend-ignore = E203, W503
```

#### Стиль кода

```python
# Хорошо
class ProductService:
    """Сервис для работы с товарами."""
    
    def __init__(self, db: Session):
        self.db = db
    
    def get_by_id(self, product_id: int) -> Optional[Product]:
        """Получение товара по ID."""
        return self.db.query(Product).filter(Product.id == product_id).first()

# Плохо
class productservice:
    def __init__(self,db):
        self.db=db
    def get_by_id(self,product_id):
        return self.db.query(Product).filter(Product.id==product_id).first()
```

### TypeScript (Frontend)

#### Конфигурация

```json
// .eslintrc.json
{
  "extends": [
    "react-app",
    "react-app/jest",
    "@typescript-eslint/recommended"
  ],
  "rules": {
    "@typescript-eslint/no-unused-vars": "error",
    "react-hooks/exhaustive-deps": "warn",
    "prefer-const": "error"
  }
}
```

#### Стиль кода

```typescript
// Хорошо
interface ProductProps {
  product: Product;
  onEdit: (product: Product) => void;
  onDelete: (id: number) => void;
}

const ProductCard: React.FC<ProductProps> = ({ product, onEdit, onDelete }) => {
  const handleEdit = useCallback(() => {
    onEdit(product);
  }, [product, onEdit]);

  return (
    <Card>
      <CardContent>
        <Typography variant="h6">{product.name}</Typography>
        <Button onClick={handleEdit}>Редактировать</Button>
      </CardContent>
    </Card>
  );
};

// Плохо
const ProductCard = ({ product, onEdit, onDelete }) => {
  return (
    <Card>
      <CardContent>
        <Typography variant="h6">{product.name}</Typography>
        <Button onClick={() => onEdit(product)}>Редактировать</Button>
      </CardContent>
    </Card>
  );
};
```

### Git Workflow

#### Commit сообщения

```bash
# Формат
<type>(<scope>): <description>

# Примеры
feat(products): add product search functionality
fix(auth): resolve token expiration issue
docs(api): update API documentation
test(forecast): add unit tests for forecast service
```

#### Типы коммитов

- `feat` - новая функциональность
- `fix` - исправление ошибки
- `docs` - документация
- `style` - форматирование кода
- `refactor` - рефакторинг
- `test` - тесты
- `chore` - обслуживание

#### Branching Strategy

```bash
# Основные ветки
main          # Production код
develop       # Development код

# Feature ветки
feature/product-search
feature/forecast-improvements

# Hotfix ветки
hotfix/critical-bug-fix

# Release ветки
release/v1.2.0
```

## 🔗 Полезные ссылки

- **Проект на GitHub**: [https://github.com/ColinsWey/inventory-system](https://github.com/ColinsWey/inventory-system)
- **API документация**: [API_DOCS.md](API_DOCS.md)
- **Архитектура системы**: [ARCHITECTURE.md](ARCHITECTURE.md)
- **Руководство пользователя**: [USER_GUIDE.md](USER_GUIDE.md)
- **Решение проблем**: [TROUBLESHOOTING.md](TROUBLESHOOTING.md)

### Внешние ресурсы

- [FastAPI документация](https://fastapi.tiangolo.com/)
- [React документация](https://react.dev/)
- [SQLAlchemy документация](https://docs.sqlalchemy.org/)
- [Material-UI документация](https://mui.com/)
- [Redux Toolkit документация](https://redux-toolkit.js.org/)

---

**Версия**: 1.0.0  
**Последнее обновление**: Январь 2024  
**Автор**: Development Team 