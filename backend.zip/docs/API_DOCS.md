# 🔧 API Документация

Полная документация REST API системы управления товарными остатками.

## 📋 Содержание

- [Обзор API](#обзор-api)
- [Аутентификация](#аутентификация)
- [Endpoints](#endpoints)
- [Модели данных](#модели-данных)
- [Примеры использования](#примеры-использования)
- [Коды ошибок](#коды-ошибок)
- [SDK и библиотеки](#sdk-и-библиотеки)

## 🌐 Обзор API

### Базовая информация

- **Базовый URL**: `http://localhost:8000/api/v1`
- **Протокол**: HTTP/HTTPS
- **Формат данных**: JSON
- **Кодировка**: UTF-8
- **Версия API**: v1

### Особенности

- RESTful архитектура
- JWT аутентификация
- Пагинация для больших наборов данных
- Фильтрация и сортировка
- Валидация входных данных
- Подробные коды ошибок

### Заголовки запросов

```http
Content-Type: application/json
Authorization: Bearer <jwt_token>
Accept: application/json
```

## 🔐 Аутентификация

### Получение токена

```http
POST /api/v1/auth/login
```

**Тело запроса:**
```json
{
  "username": "admin",
  "password": "admin"
}
```

**Ответ:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 3600,
  "user": {
    "id": 1,
    "username": "admin",
    "email": "admin@example.com",
    "role": "admin"
  }
}
```

### Обновление токена

```http
POST /api/v1/auth/refresh
```

**Заголовки:**
```http
Authorization: Bearer <refresh_token>
```

### Выход из системы

```http
POST /api/v1/auth/logout
```

## 📊 Endpoints

### Товары (Products)

#### Получить список товаров

```http
GET /api/v1/products
```

**Параметры запроса:**
- `page` (int) - номер страницы (по умолчанию: 1)
- `limit` (int) - количество элементов на странице (по умолчанию: 20)
- `category_id` (int) - фильтр по категории
- `search` (string) - поиск по названию или SKU
- `min_stock` (int) - минимальный остаток
- `max_stock` (int) - максимальный остаток
- `sort_by` (string) - поле для сортировки
- `sort_order` (string) - порядок сортировки (asc/desc)

**Пример запроса:**
```http
GET /api/v1/products?page=1&limit=10&category_id=1&search=iPhone
```

**Ответ:**
```json
{
  "items": [
    {
      "id": 1,
      "name": "iPhone 15 Pro 128GB",
      "sku": "IPHONE15PRO128",
      "category_id": 1,
      "category_name": "Электроника",
      "price": 89990.00,
      "cost": 65000.00,
      "current_stock": 25,
      "min_stock": 5,
      "max_stock": 100,
      "supplier": "Apple",
      "lead_time_days": 7,
      "is_seasonal": false,
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": "2024-01-20T14:45:00Z"
    }
  ],
  "total": 1,
  "page": 1,
  "pages": 1,
  "per_page": 10
}
```

#### Получить товар по ID

```http
GET /api/v1/products/{product_id}
```

**Ответ:**
```json
{
  "id": 1,
  "name": "iPhone 15 Pro 128GB",
  "sku": "IPHONE15PRO128",
  "category_id": 1,
  "category": {
    "id": 1,
    "name": "Электроника",
    "description": "Электронные устройства"
  },
  "price": 89990.00,
  "cost": 65000.00,
  "current_stock": 25,
  "min_stock": 5,
  "max_stock": 100,
  "supplier": {
    "id": 1,
    "name": "Apple",
    "contact_email": "orders@apple.com"
  },
  "lead_time_days": 7,
  "is_seasonal": false,
  "tags": ["premium", "smartphone", "apple"],
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-20T14:45:00Z"
}
```

#### Создать товар

```http
POST /api/v1/products
```

**Тело запроса:**
```json
{
  "name": "Samsung Galaxy S24 256GB",
  "sku": "GALAXYS24256",
  "category_id": 1,
  "price": 79990.00,
  "cost": 58000.00,
  "current_stock": 18,
  "min_stock": 3,
  "max_stock": 80,
  "supplier_id": 2,
  "lead_time_days": 5,
  "is_seasonal": false,
  "tags": ["premium", "smartphone", "samsung"]
}
```

#### Обновить товар

```http
PUT /api/v1/products/{product_id}
```

#### Удалить товар

```http
DELETE /api/v1/products/{product_id}
```

### Категории (Categories)

#### Получить список категорий

```http
GET /api/v1/categories
```

**Ответ:**
```json
{
  "items": [
    {
      "id": 1,
      "name": "Электроника",
      "description": "Электронные устройства и аксессуары",
      "seasonality_template": "electronics",
      "products_count": 15,
      "created_at": "2024-01-01T00:00:00Z"
    }
  ]
}
```

#### Создать категорию

```http
POST /api/v1/categories
```

**Тело запроса:**
```json
{
  "name": "Бытовая техника",
  "description": "Техника для дома",
  "seasonality_template": "appliances"
}
```

### Прогнозирование (Forecasting)

#### Создать прогноз

```http
POST /api/v1/forecasts
```

**Тело запроса:**
```json
{
  "product_id": 1,
  "forecast_days": 30,
  "apply_seasonality": true,
  "exclude_wholesale": true,
  "confidence_level": 0.95,
  "price_adjustment": {
    "new_price": 95000.00,
    "price_elasticity": -0.5
  },
  "promotions": [
    {
      "start_date": "2024-11-24",
      "end_date": "2024-11-27",
      "discount_percent": 20,
      "expected_uplift": 1.5
    }
  ]
}
```

**Ответ:**
```json
{
  "id": 123,
  "product_id": 1,
  "forecast_days": 30,
  "created_at": "2024-01-20T15:00:00Z",
  "forecast_data": [
    {
      "date": "2024-01-21",
      "quantity": 12.5,
      "confidence_interval": {
        "lower": 8.2,
        "upper": 16.8
      }
    }
  ],
  "summary": {
    "total_demand": 375,
    "avg_daily_demand": 12.5,
    "peak_day": "2024-11-25",
    "peak_demand": 25.3
  },
  "recommendations": {
    "recommended_order_quantity": 400,
    "reorder_point": 50,
    "safety_stock": 25
  },
  "accuracy_metrics": {
    "mae": 2.1,
    "mape": 15.2,
    "rmse": 3.4
  }
}
```

#### Получить прогноз

```http
GET /api/v1/forecasts/{forecast_id}
```

#### Получить список прогнозов

```http
GET /api/v1/forecasts
```

**Параметры:**
- `product_id` (int) - фильтр по товару
- `date_from` (date) - начальная дата
- `date_to` (date) - конечная дата

### Продажи (Sales)

#### Получить историю продаж

```http
GET /api/v1/sales
```

**Параметры:**
- `product_id` (int) - фильтр по товару
- `date_from` (date) - начальная дата
- `date_to` (date) - конечная дата
- `is_wholesale` (bool) - только оптовые/розничные

**Ответ:**
```json
{
  "items": [
    {
      "id": 1,
      "product_id": 1,
      "product_name": "iPhone 15 Pro 128GB",
      "quantity": 5,
      "price": 89990.00,
      "total_amount": 449950.00,
      "is_wholesale": false,
      "sale_date": "2024-01-20T12:30:00Z",
      "customer_id": 123
    }
  ],
  "total": 1,
  "page": 1,
  "pages": 1
}
```

#### Добавить продажу

```http
POST /api/v1/sales
```

**Тело запроса:**
```json
{
  "product_id": 1,
  "quantity": 2,
  "price": 89990.00,
  "is_wholesale": false,
  "sale_date": "2024-01-20T12:30:00Z",
  "customer_id": 123
}
```

### Отчеты (Reports)

#### Отчет по остаткам

```http
GET /api/v1/reports/inventory
```

**Параметры:**
- `category_id` (int) - фильтр по категории
- `low_stock_only` (bool) - только товары с низким остатком

**Ответ:**
```json
{
  "summary": {
    "total_products": 150,
    "low_stock_products": 12,
    "out_of_stock_products": 3,
    "total_value": 2500000.00
  },
  "categories": [
    {
      "category_id": 1,
      "category_name": "Электроника",
      "products_count": 15,
      "total_value": 1200000.00,
      "low_stock_count": 3
    }
  ],
  "low_stock_products": [
    {
      "product_id": 1,
      "name": "iPhone 15 Pro 128GB",
      "current_stock": 3,
      "min_stock": 5,
      "recommended_order": 50
    }
  ]
}
```

#### ABC анализ

```http
GET /api/v1/reports/abc-analysis
```

**Параметры:**
- `period_days` (int) - период анализа в днях (по умолчанию: 365)

**Ответ:**
```json
{
  "analysis_period": {
    "start_date": "2023-01-20",
    "end_date": "2024-01-20",
    "days": 365
  },
  "summary": {
    "total_revenue": 5000000.00,
    "total_products": 150
  },
  "groups": {
    "A": {
      "products_count": 30,
      "products_percentage": 20.0,
      "revenue": 4000000.00,
      "revenue_percentage": 80.0
    },
    "B": {
      "products_count": 45,
      "products_percentage": 30.0,
      "revenue": 750000.00,
      "revenue_percentage": 15.0
    },
    "C": {
      "products_count": 75,
      "products_percentage": 50.0,
      "revenue": 250000.00,
      "revenue_percentage": 5.0
    }
  },
  "products": [
    {
      "product_id": 1,
      "name": "iPhone 15 Pro 128GB",
      "group": "A",
      "revenue": 450000.00,
      "revenue_percentage": 9.0,
      "quantity_sold": 50
    }
  ]
}
```

### Интеграция (Integration)

#### Импорт из SalesDrive

```http
POST /api/v1/integration/salesdrive/import
```

**Тело запроса:**
```json
{
  "data_type": "sales",
  "date_from": "2024-01-01",
  "date_to": "2024-01-20",
  "categories": [1, 2, 3],
  "update_mode": "append"
}
```

**Ответ:**
```json
{
  "import_id": "imp_123456",
  "status": "started",
  "estimated_duration": 300,
  "progress_url": "/api/v1/integration/imports/imp_123456/progress"
}
```

#### Статус импорта

```http
GET /api/v1/integration/imports/{import_id}/progress
```

**Ответ:**
```json
{
  "import_id": "imp_123456",
  "status": "completed",
  "progress": 100,
  "started_at": "2024-01-20T15:00:00Z",
  "completed_at": "2024-01-20T15:05:00Z",
  "statistics": {
    "total_records": 1000,
    "imported_records": 950,
    "updated_records": 45,
    "failed_records": 5,
    "errors": [
      {
        "row": 15,
        "error": "Invalid SKU format",
        "data": {"sku": "INVALID-SKU"}
      }
    ]
  }
}
```

### Уведомления (Notifications)

#### Получить уведомления

```http
GET /api/v1/notifications
```

**Параметры:**
- `unread_only` (bool) - только непрочитанные
- `type` (string) - тип уведомления

**Ответ:**
```json
{
  "items": [
    {
      "id": 1,
      "type": "low_stock",
      "title": "Низкий остаток товара",
      "message": "У товара iPhone 15 Pro остаток ниже минимального уровня",
      "data": {
        "product_id": 1,
        "current_stock": 3,
        "min_stock": 5
      },
      "is_read": false,
      "created_at": "2024-01-20T10:00:00Z"
    }
  ]
}
```

#### Отметить как прочитанное

```http
PUT /api/v1/notifications/{notification_id}/read
```

## 📋 Модели данных

### Product (Товар)

```json
{
  "id": "integer",
  "name": "string (required, max 255)",
  "sku": "string (required, unique, max 50)",
  "category_id": "integer (required)",
  "price": "decimal (required, min 0)",
  "cost": "decimal (min 0)",
  "current_stock": "integer (required, min 0)",
  "min_stock": "integer (min 0)",
  "max_stock": "integer (min 0)",
  "supplier_id": "integer",
  "lead_time_days": "integer (min 0)",
  "is_seasonal": "boolean",
  "tags": "array of strings",
  "created_at": "datetime",
  "updated_at": "datetime"
}
```

### Category (Категория)

```json
{
  "id": "integer",
  "name": "string (required, max 100)",
  "description": "string (max 500)",
  "seasonality_template": "string",
  "created_at": "datetime",
  "updated_at": "datetime"
}
```

### Sale (Продажа)

```json
{
  "id": "integer",
  "product_id": "integer (required)",
  "quantity": "integer (required, min 1)",
  "price": "decimal (required, min 0)",
  "total_amount": "decimal (computed)",
  "is_wholesale": "boolean",
  "sale_date": "datetime (required)",
  "customer_id": "integer",
  "created_at": "datetime"
}
```

### Forecast (Прогноз)

```json
{
  "id": "integer",
  "product_id": "integer (required)",
  "forecast_days": "integer (required, min 1, max 365)",
  "apply_seasonality": "boolean",
  "exclude_wholesale": "boolean",
  "confidence_level": "decimal (min 0.5, max 0.99)",
  "forecast_data": "array of forecast points",
  "summary": "object",
  "recommendations": "object",
  "accuracy_metrics": "object",
  "created_at": "datetime"
}
```

## 💡 Примеры использования

### Python

```python
import requests

# Аутентификация
auth_response = requests.post(
    'http://localhost:8000/api/v1/auth/login',
    json={'username': 'admin', 'password': 'admin'}
)
token = auth_response.json()['access_token']

headers = {'Authorization': f'Bearer {token}'}

# Получение списка товаров
products_response = requests.get(
    'http://localhost:8000/api/v1/products',
    headers=headers,
    params={'category_id': 1, 'limit': 10}
)
products = products_response.json()

# Создание прогноза
forecast_data = {
    'product_id': 1,
    'forecast_days': 30,
    'apply_seasonality': True,
    'confidence_level': 0.95
}

forecast_response = requests.post(
    'http://localhost:8000/api/v1/forecasts',
    headers=headers,
    json=forecast_data
)
forecast = forecast_response.json()
```

### JavaScript

```javascript
// Аутентификация
const authResponse = await fetch('/api/v1/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username: 'admin', password: 'admin' })
});
const { access_token } = await authResponse.json();

const headers = { 
  'Authorization': `Bearer ${access_token}`,
  'Content-Type': 'application/json'
};

// Получение товаров
const productsResponse = await fetch('/api/v1/products?limit=10', { headers });
const products = await productsResponse.json();

// Создание товара
const newProduct = {
  name: 'New Product',
  sku: 'NEW001',
  category_id: 1,
  price: 1000.00,
  current_stock: 50
};

const createResponse = await fetch('/api/v1/products', {
  method: 'POST',
  headers,
  body: JSON.stringify(newProduct)
});
```

### cURL

```bash
# Аутентификация
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "admin"}'

# Получение товаров (замените TOKEN на полученный токен)
curl -X GET http://localhost:8000/api/v1/products \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json"

# Создание прогноза
curl -X POST http://localhost:8000/api/v1/forecasts \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "product_id": 1,
    "forecast_days": 30,
    "apply_seasonality": true,
    "confidence_level": 0.95
  }'
```

## ❌ Коды ошибок

### HTTP статус коды

- `200` - OK
- `201` - Created
- `204` - No Content
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `422` - Validation Error
- `500` - Internal Server Error

### Формат ошибок

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Validation failed",
    "details": [
      {
        "field": "price",
        "message": "Price must be greater than 0"
      }
    ]
  }
}
```

### Коды ошибок приложения

| Код | Описание |
|-----|----------|
| `VALIDATION_ERROR` | Ошибка валидации данных |
| `AUTHENTICATION_FAILED` | Неверные учетные данные |
| `TOKEN_EXPIRED` | Токен истек |
| `INSUFFICIENT_PERMISSIONS` | Недостаточно прав |
| `RESOURCE_NOT_FOUND` | Ресурс не найден |
| `DUPLICATE_SKU` | SKU уже существует |
| `INSUFFICIENT_STOCK` | Недостаточно товара на складе |
| `FORECAST_ERROR` | Ошибка при расчете прогноза |
| `IMPORT_ERROR` | Ошибка импорта данных |

## 📚 SDK и библиотеки

### Официальные SDK

В разработке:
- Python SDK
- JavaScript/TypeScript SDK
- PHP SDK

### Неофициальные библиотеки

Сообщество разрабатывает библиотеки для различных языков программирования. Актуальный список доступен в [Wiki проекта](https://github.com/ColinsWey/inventory-system/wiki).

### OpenAPI спецификация

Полная OpenAPI (Swagger) спецификация доступна по адресу:
- **Swagger UI**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`
- **OpenAPI JSON**: `http://localhost:8000/openapi.json`

## 🔗 Полезные ссылки

- [Главная страница проекта](https://github.com/ColinsWey/inventory-system)
- [Руководство пользователя](USER_GUIDE.md)
- [Руководство по установке](INSTALL.md)
- [Решение проблем](TROUBLESHOOTING.md)
- [Примеры кода](https://github.com/ColinsWey/inventory-system/tree/main/examples)

---

**Версия API**: v1  
**Последнее обновление**: Январь 2024 