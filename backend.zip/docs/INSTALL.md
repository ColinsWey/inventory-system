# 📖 Руководство по установке

Подробная инструкция по установке и настройке системы управления товарными остатками.

## 📋 Содержание

- [Системные требования](#системные-требования)
- [Быстрая установка](#быстрая-установка)
- [Подробная установка](#подробная-установка)
- [Настройка для разработки](#настройка-для-разработки)
- [Настройка для production](#настройка-для-production)
- [Проверка установки](#проверка-установки)
- [Устранение проблем](#устранение-проблем)

## 🔧 Системные требования

### Минимальные требования

- **ОС**: Windows 10/11, macOS 10.15+, Ubuntu 20.04+
- **RAM**: 4 GB (рекомендуется 8 GB)
- **Диск**: 10 GB свободного места
- **CPU**: 2 ядра (рекомендуется 4 ядра)

### Рекомендуемые требования для production

- **ОС**: Ubuntu Server 22.04 LTS
- **RAM**: 16 GB
- **Диск**: 50 GB SSD
- **CPU**: 4+ ядра
- **Сеть**: статический IP и доменное имя

### Программное обеспечение

**Обязательно:**
- [Docker](https://docs.docker.com/get-docker/) 20.10+
- [Docker Compose](https://docs.docker.com/compose/install/) 2.0+
- [Git](https://git-scm.com/downloads)

**Для разработки:**
- [Python](https://python.org/downloads/) 3.9+
- [Node.js](https://nodejs.org/) 16+
- [PostgreSQL](https://postgresql.org/download/) 13+ (опционально)

## 🚀 Быстрая установка

### 1. Клонирование репозитория

```bash
# Клонирование проекта
git clone https://github.com/ColinsWey/inventory-system.git
cd inventory-system
```

### 2. Запуск через Docker

```bash
# Запуск всех сервисов
docker-compose up -d

# Проверка статуса
docker-compose ps
```

### 3. Первый вход

Откройте браузер и перейдите по адресу: http://localhost:3000

**Данные для входа:**
- Логин: `admin`
- Пароль: `admin`

## 📖 Подробная установка

### Шаг 1: Подготовка системы

#### Ubuntu/Debian

```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка зависимостей
sudo apt install -y curl wget git software-properties-common

# Установка Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Добавление пользователя в группу docker
sudo usermod -aG docker $USER

# Установка Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Перезагрузка для применения изменений
sudo reboot
```

#### Windows

1. Установите [Docker Desktop](https://docs.docker.com/desktop/windows/install/)
2. Установите [Git for Windows](https://git-scm.com/download/win)
3. Перезагрузите компьютер

#### macOS

```bash
# Установка через Homebrew
brew install docker docker-compose git

# Или скачайте Docker Desktop с официального сайта
```

### Шаг 2: Клонирование и настройка

```bash
# Клонирование репозитория
git clone https://github.com/ColinsWey/inventory-system.git
cd inventory-system

# Создание файла конфигурации
cp .env.example .env

# Редактирование конфигурации (опционально)
nano .env  # Linux/macOS
notepad .env  # Windows
```

### Шаг 3: Настройка переменных окружения

Отредактируйте файл `.env`:

```bash
# Основные настройки
APP_NAME=Inventory Management System
APP_ENV=production
DEBUG=false

# База данных
POSTGRES_DB=inventory_db
POSTGRES_USER=inventory_user
POSTGRES_PASSWORD=secure_password_123

# Redis
REDIS_PASSWORD=redis_password_456

# Безопасность
SECRET_KEY=your_secret_key_here
JWT_SECRET_KEY=your_jwt_secret_here

# API интеграции
SALESDRIVE_API_KEY=your_salesdrive_api_key
SALESDRIVE_API_URL=https://api.salesdrive.com

# Email настройки
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_app_password

# Домен (для production)
APP_DOMAIN=your-domain.com
```

### Шаг 4: Запуск приложения

```bash
# Сборка образов
docker-compose build

# Запуск всех сервисов
docker-compose up -d

# Проверка статуса
docker-compose ps

# Просмотр логов
docker-compose logs -f
```

### Шаг 5: Инициализация базы данных

```bash
# Применение миграций
docker-compose exec backend alembic upgrade head

# Создание начальных данных
docker-compose exec backend python scripts/init_data.py
```

## 🛠️ Настройка для разработки

### Установка зависимостей

```bash
# Backend зависимости
python -m venv venv
source venv/bin/activate  # Linux/macOS
# или venv\Scripts\activate  # Windows

pip install -r requirements.txt
pip install -r requirements-dev.txt

# Frontend зависимости
cd frontend
npm install
cd ..
```

### Настройка базы данных

```bash
# Запуск только PostgreSQL и Redis
docker-compose up -d postgres redis

# Применение миграций
alembic upgrade head

# Создание тестовых данных
python scripts/create_test_data.py
```

### Запуск в режиме разработки

```bash
# Терминал 1: Backend
cd backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Терминал 2: Frontend
cd frontend
npm start

# Терминал 3: Celery worker (опционально)
cd backend
celery -A app.celery worker --loglevel=info
```

### Настройка IDE

#### VS Code

Установите расширения:
- Python
- Pylance
- ES7+ React/Redux/React-Native snippets
- Prettier
- ESLint

#### PyCharm

1. Откройте проект
2. Настройте интерпретатор Python (venv)
3. Настройте запуск FastAPI
4. Настройте подключение к базе данных

## 🌐 Настройка для production

### Подготовка сервера

```bash
# Создание пользователя для приложения
sudo adduser inventory
sudo usermod -aG docker inventory
sudo su - inventory

# Клонирование в домашнюю директорию
git clone https://github.com/ColinsWey/inventory-system.git
cd inventory-system
```

### Настройка SSL сертификатов

```bash
# Установка Certbot
sudo apt install -y certbot

# Получение SSL сертификата
sudo certbot certonly --standalone -d your-domain.com

# Копирование сертификатов
sudo cp /etc/letsencrypt/live/your-domain.com/fullchain.pem ssl/
sudo cp /etc/letsencrypt/live/your-domain.com/privkey.pem ssl/
sudo chown inventory:inventory ssl/*
```

### Настройка Nginx

```bash
# Создание конфигурации Nginx
sudo nano /etc/nginx/sites-available/inventory

# Содержимое конфигурации
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /path/to/ssl/fullchain.pem;
    ssl_certificate_key /path/to/ssl/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /api/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# Активация конфигурации
sudo ln -s /etc/nginx/sites-available/inventory /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Настройка автозапуска

```bash
# Создание systemd сервиса
sudo nano /etc/systemd/system/inventory.service

# Содержимое сервиса
[Unit]
Description=Inventory Management System
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/home/inventory/inventory-system
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
TimeoutStartSec=0
User=inventory

[Install]
WantedBy=multi-user.target

# Активация сервиса
sudo systemctl enable inventory.service
sudo systemctl start inventory.service
```

### Настройка резервного копирования

```bash
# Создание скрипта backup
nano scripts/backup.sh

#!/bin/bash
BACKUP_DIR="/home/inventory/backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup базы данных
docker-compose exec -T postgres pg_dump -U inventory_user inventory_db > $BACKUP_DIR/db_backup_$DATE.sql

# Backup файлов
tar -czf $BACKUP_DIR/files_backup_$DATE.tar.gz uploads/

# Удаление старых backup (старше 30 дней)
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete

# Добавление в crontab
chmod +x scripts/backup.sh
crontab -e

# Добавить строку для ежедневного backup в 2:00
0 2 * * * /home/inventory/inventory-system/scripts/backup.sh
```

## ✅ Проверка установки

### Проверка сервисов

```bash
# Статус контейнеров
docker-compose ps

# Проверка логов
docker-compose logs

# Проверка здоровья сервисов
curl http://localhost:8000/health
curl http://localhost:3000
```

### Проверка базы данных

```bash
# Подключение к базе данных
docker-compose exec postgres psql -U inventory_user -d inventory_db

# Проверка таблиц
\dt

# Выход из psql
\q
```

### Проверка API

```bash
# Проверка API endpoints
curl http://localhost:8000/api/v1/health
curl http://localhost:8000/api/v1/products

# Проверка авторизации
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "admin"}'
```

### Функциональная проверка

1. Откройте http://localhost:3000
2. Войдите с данными admin/admin
3. Проверьте основные разделы:
   - Дашборд
   - Товары
   - Прогнозирование
   - Отчеты

## 🐛 Устранение проблем

### Проблемы с Docker

```bash
# Проверка версии Docker
docker --version
docker-compose --version

# Перезапуск Docker
sudo systemctl restart docker

# Очистка Docker
docker system prune -a
```

### Проблемы с портами

```bash
# Проверка занятых портов
netstat -tulpn | grep :3000
netstat -tulpn | grep :8000
netstat -tulpn | grep :5432

# Остановка процессов на портах
sudo lsof -ti:3000 | xargs kill -9
```

### Проблемы с базой данных

```bash
# Пересоздание базы данных
docker-compose down
docker volume rm inventory-system_postgres_data
docker-compose up -d postgres
docker-compose exec backend alembic upgrade head
```

### Проблемы с правами доступа

```bash
# Исправление прав на файлы
sudo chown -R $USER:$USER .
chmod +x scripts/*.sh
```

### Логи для диагностики

```bash
# Подробные логи всех сервисов
docker-compose logs -f

# Логи конкретного сервиса
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f postgres

# Системные логи
sudo journalctl -u docker.service
sudo journalctl -u inventory.service
```

## 📞 Получение помощи

Если у вас возникли проблемы с установкой:

1. Проверьте [FAQ](TROUBLESHOOTING.md)
2. Создайте [Issue на GitHub](https://github.com/ColinsWey/inventory-system/issues)
3. Обратитесь к [документации](https://github.com/ColinsWey/inventory-system/wiki)

При создании Issue укажите:
- Операционную систему
- Версии Docker и Docker Compose
- Полный текст ошибки
- Логи сервисов

---

**Следующий шаг:** [Руководство пользователя](USER_GUIDE.md) 