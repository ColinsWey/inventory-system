# 🏗️ Архитектура системы

Техническая документация архитектуры системы управления товарными остатками.

## 📋 Содержание

- [Обзор архитектуры](#обзор-архитектуры)
- [Компоненты системы](#компоненты-системы)
- [Схема базы данных](#схема-базы-данных)
- [API архитектура](#api-архитектура)
- [Безопасность](#безопасность)
- [Масштабирование](#масштабирование)
- [Мониторинг](#мониторинг)

## 🌐 Обзор архитектуры

### Общая схема

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │    Backend      │    │   Database      │
│   (React)       │◄──►│   (FastAPI)     │◄──►│  (PostgreSQL)   │
│   Port: 3000    │    │   Port: 8000    │    │   Port: 5432    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │              ┌─────────────────┐              │
         │              │     Redis       │              │
         └──────────────►│   (Cache)       │◄─────────────┘
                        │   Port: 6379    │
                        └─────────────────┘
                                 │
                        ┌─────────────────┐
                        │     Celery      │
                        │   (Workers)     │
                        └─────────────────┘
```

### Принципы архитектуры

- **Микросервисная архитектура** - разделение на независимые сервисы
- **RESTful API** - стандартизированное взаимодействие
- **Контейнеризация** - Docker для изоляции и развертывания
- **Горизонтальное масштабирование** - возможность добавления узлов
- **Кэширование** - Redis для повышения производительности
- **Асинхронная обработка** - Celery для фоновых задач

## 🔧 Компоненты системы

### Frontend (React)

**Технологии:**
- React 18+ с TypeScript
- Material-UI для компонентов
- Redux Toolkit для управления состоянием
- React Router для навигации
- Axios для HTTP запросов
- Chart.js для графиков

**Структура:**
```
frontend/
├── src/
│   ├── components/     # Переиспользуемые компоненты
│   ├── pages/         # Страницы приложения
│   ├── store/         # Redux store и slices
│   ├── services/      # API сервисы
│   ├── hooks/         # Пользовательские хуки
│   ├── utils/         # Утилиты
│   └── types/         # TypeScript типы
├── public/            # Статические файлы
└── package.json       # Зависимости
```

**Ключевые особенности:**
- Server-Side Rendering (SSR) готовность
- Progressive Web App (PWA) поддержка
- Адаптивный дизайн
- Интернационализация (i18n)
- Темная/светлая тема

### Backend (FastAPI)

**Технологии:**
- FastAPI с Python 3.9+
- SQLAlchemy ORM
- Alembic для миграций
- Pydantic для валидации
- JWT для аутентификации
- Celery для фоновых задач

**Структура:**
```
backend/
├── app/
│   ├── api/           # API endpoints
│   ├── core/          # Конфигурация и настройки
│   ├── models/        # SQLAlchemy модели
│   ├── schemas/       # Pydantic схемы
│   ├── services/      # Бизнес логика
│   ├── utils/         # Утилиты
│   └── workers/       # Celery задачи
├── alembic/           # Миграции базы данных
├── tests/             # Тесты
└── requirements.txt   # Зависимости
```

**Архитектурные слои:**
1. **API Layer** - обработка HTTP запросов
2. **Service Layer** - бизнес логика
3. **Repository Layer** - доступ к данным
4. **Model Layer** - модели данных

### База данных (PostgreSQL)

**Особенности:**
- ACID транзакции
- Индексы для оптимизации запросов
- Партиционирование больших таблиц
- Репликация для отказоустойчивости
- Регулярные бэкапы

**Оптимизации:**
- Индексы на часто используемые поля
- Материализованные представления для отчетов
- Партиционирование таблицы продаж по датам
- Connection pooling

### Кэш (Redis)

**Использование:**
- Кэширование результатов прогнозов
- Сессии пользователей
- Очередь задач для Celery
- Временные данные импорта

**Конфигурация:**
```redis
# Политика вытеснения
maxmemory-policy allkeys-lru

# Персистентность
save 900 1
save 300 10
save 60 10000
```

### Очередь задач (Celery)

**Задачи:**
- Расчет прогнозов спроса
- Импорт данных из внешних API
- Генерация отчетов
- Отправка уведомлений

**Конфигурация:**
```python
# celery_config.py
broker_url = 'redis://redis:6379/0'
result_backend = 'redis://redis:6379/0'
task_serializer = 'json'
accept_content = ['json']
result_serializer = 'json'
timezone = 'Europe/Moscow'
```

## 🗄️ Схема базы данных

### Основные таблицы

#### Users (Пользователи)
```sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'user',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Categories (Категории)
```sql
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    seasonality_template VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Products (Товары)
```sql
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    sku VARCHAR(50) UNIQUE NOT NULL,
    category_id INTEGER REFERENCES categories(id),
    price DECIMAL(10,2) NOT NULL,
    cost DECIMAL(10,2),
    current_stock INTEGER NOT NULL DEFAULT 0,
    min_stock INTEGER DEFAULT 0,
    max_stock INTEGER DEFAULT 0,
    supplier_id INTEGER REFERENCES suppliers(id),
    lead_time_days INTEGER DEFAULT 0,
    is_seasonal BOOLEAN DEFAULT false,
    tags TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Индексы
CREATE INDEX idx_products_sku ON products(sku);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_stock ON products(current_stock);
```

#### Sales (Продажи)
```sql
CREATE TABLE sales (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id),
    quantity INTEGER NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    total_amount DECIMAL(10,2) GENERATED ALWAYS AS (quantity * price) STORED,
    is_wholesale BOOLEAN DEFAULT false,
    sale_date TIMESTAMP NOT NULL,
    customer_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) PARTITION BY RANGE (sale_date);

-- Партиции по месяцам
CREATE TABLE sales_2024_01 PARTITION OF sales
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

-- Индексы
CREATE INDEX idx_sales_product_date ON sales(product_id, sale_date);
CREATE INDEX idx_sales_date ON sales(sale_date);
```

#### Forecasts (Прогнозы)
```sql
CREATE TABLE forecasts (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id),
    forecast_days INTEGER NOT NULL,
    apply_seasonality BOOLEAN DEFAULT false,
    exclude_wholesale BOOLEAN DEFAULT true,
    confidence_level DECIMAL(3,2) DEFAULT 0.95,
    forecast_data JSONB NOT NULL,
    summary JSONB,
    recommendations JSONB,
    accuracy_metrics JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Индексы
CREATE INDEX idx_forecasts_product ON forecasts(product_id);
CREATE INDEX idx_forecasts_created ON forecasts(created_at);
CREATE INDEX idx_forecasts_data ON forecasts USING GIN(forecast_data);
```

### Связи между таблицами

```mermaid
erDiagram
    USERS ||--o{ FORECASTS : creates
    CATEGORIES ||--o{ PRODUCTS : contains
    PRODUCTS ||--o{ SALES : sold
    PRODUCTS ||--o{ FORECASTS : forecasted
    SUPPLIERS ||--o{ PRODUCTS : supplies
    
    USERS {
        int id PK
        string username
        string email
        string password_hash
        string role
    }
    
    CATEGORIES {
        int id PK
        string name
        string description
        string seasonality_template
    }
    
    PRODUCTS {
        int id PK
        string name
        string sku
        int category_id FK
        decimal price
        int current_stock
        int min_stock
        int max_stock
    }
    
    SALES {
        int id PK
        int product_id FK
        int quantity
        decimal price
        boolean is_wholesale
        timestamp sale_date
    }
    
    FORECASTS {
        int id PK
        int product_id FK
        int forecast_days
        jsonb forecast_data
        jsonb summary
    }
```

## 🔌 API архитектура

### RESTful принципы

**Структура URL:**
```
/api/v1/{resource}/{id?}/{action?}
```

**HTTP методы:**
- `GET` - получение данных
- `POST` - создание ресурса
- `PUT` - полное обновление
- `PATCH` - частичное обновление
- `DELETE` - удаление

**Коды ответов:**
- `200` - успешный запрос
- `201` - ресурс создан
- `400` - ошибка валидации
- `401` - не авторизован
- `403` - нет прав доступа
- `404` - ресурс не найден
- `500` - внутренняя ошибка

### Middleware

**Порядок обработки:**
1. **CORS Middleware** - настройка CORS заголовков
2. **Authentication Middleware** - проверка JWT токена
3. **Rate Limiting Middleware** - ограничение запросов
4. **Logging Middleware** - логирование запросов
5. **Error Handling Middleware** - обработка ошибок

### Валидация данных

**Pydantic схемы:**
```python
class ProductCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    sku: str = Field(..., min_length=1, max_length=50)
    category_id: int = Field(..., gt=0)
    price: Decimal = Field(..., gt=0)
    current_stock: int = Field(..., ge=0)
    
    @validator('sku')
    def validate_sku(cls, v):
        if not re.match(r'^[A-Z0-9_-]+$', v):
            raise ValueError('SKU должен содержать только буквы, цифры, _ и -')
        return v
```

## 🔒 Безопасность

### Аутентификация и авторизация

**JWT токены:**
```python
# Структура токена
{
    "sub": "user_id",
    "username": "admin",
    "role": "admin",
    "exp": 1640995200,
    "iat": 1640908800
}
```

**Роли пользователей:**
- `admin` - полный доступ
- `manager` - управление товарами и отчеты
- `user` - только просмотр

### Защита от атак

**SQL Injection:**
- Использование ORM (SQLAlchemy)
- Параметризованные запросы
- Валидация входных данных

**XSS (Cross-Site Scripting):**
- Экранирование HTML
- Content Security Policy (CSP)
- Валидация на frontend и backend

**CSRF (Cross-Site Request Forgery):**
- CSRF токены
- SameSite cookies
- Проверка Origin заголовков

**Rate Limiting:**
```python
# Ограничения по эндпоинтам
@limiter.limit("100/minute")
async def get_products():
    pass

@limiter.limit("10/minute")
async def create_forecast():
    pass
```

### Шифрование

**Пароли:**
```python
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)
```

**Данные в покое:**
- Шифрование чувствительных полей в БД
- Encrypted volumes для Docker

**Данные в движении:**
- HTTPS/TLS для всех соединений
- Шифрование соединений с БД

## 📈 Масштабирование

### Горизонтальное масштабирование

**Load Balancer:**
```nginx
upstream backend {
    server backend1:8000;
    server backend2:8000;
    server backend3:8000;
}

server {
    listen 80;
    location /api/ {
        proxy_pass http://backend;
    }
}
```

**Database Sharding:**
```python
# Шардинг по product_id
def get_shard(product_id: int) -> str:
    shard_num = product_id % 4
    return f"shard_{shard_num}"
```

### Кэширование

**Многоуровневое кэширование:**
1. **Browser Cache** - статические ресурсы
2. **CDN Cache** - глобальное кэширование
3. **Application Cache** - Redis
4. **Database Cache** - query cache

**Стратегии кэширования:**
```python
# Cache-aside pattern
async def get_product(product_id: int):
    # Проверяем кэш
    cached = await redis.get(f"product:{product_id}")
    if cached:
        return json.loads(cached)
    
    # Загружаем из БД
    product = await db.get_product(product_id)
    
    # Сохраняем в кэш
    await redis.setex(
        f"product:{product_id}", 
        3600, 
        json.dumps(product)
    )
    return product
```

### Оптимизация производительности

**Database:**
- Индексы на часто используемые поля
- Партиционирование больших таблиц
- Read replicas для чтения
- Connection pooling

**Application:**
- Асинхронное программирование
- Пагинация для больших списков
- Lazy loading для связанных данных
- Batch операции

**Frontend:**
- Code splitting
- Lazy loading компонентов
- Виртуализация длинных списков
- Service Workers для кэширования

## 📊 Мониторинг

### Метрики приложения

**Ключевые метрики:**
- Response time по эндпоинтам
- Throughput (RPS)
- Error rate
- Database query time
- Cache hit ratio

**Prometheus метрики:**
```python
from prometheus_client import Counter, Histogram

REQUEST_COUNT = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status']
)

REQUEST_DURATION = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration'
)
```

### Логирование

**Структурированные логи:**
```python
import structlog

logger = structlog.get_logger()

logger.info(
    "Product created",
    product_id=123,
    user_id=456,
    sku="IPHONE15PRO"
)
```

**Уровни логирования:**
- `DEBUG` - детальная отладочная информация
- `INFO` - общая информация о работе
- `WARNING` - предупреждения
- `ERROR` - ошибки приложения
- `CRITICAL` - критические ошибки

### Алерты

**Настройка уведомлений:**
```yaml
# alertmanager.yml
groups:
- name: inventory-system
  rules:
  - alert: HighErrorRate
    expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.1
    for: 5m
    annotations:
      summary: "High error rate detected"
      
  - alert: DatabaseDown
    expr: up{job="postgres"} == 0
    for: 1m
    annotations:
      summary: "Database is down"
```

### Health Checks

**Проверки состояния:**
```python
@app.get("/health")
async def health_check():
    checks = {
        "database": await check_database(),
        "redis": await check_redis(),
        "external_api": await check_external_api()
    }
    
    status = "healthy" if all(checks.values()) else "unhealthy"
    
    return {
        "status": status,
        "checks": checks,
        "timestamp": datetime.utcnow()
    }
```

## 🔗 Интеграции

### Внешние API

**SalesDrive API:**
```python
class SalesDriveClient:
    def __init__(self, api_key: str, base_url: str):
        self.api_key = api_key
        self.base_url = base_url
        
    async def get_sales(self, date_from: date, date_to: date):
        headers = {"Authorization": f"Bearer {self.api_key}"}
        params = {"from": date_from, "to": date_to}
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.base_url}/sales",
                headers=headers,
                params=params
            )
            return response.json()
```

### Webhook'и

**Уведомления о событиях:**
```python
async def send_webhook(event: str, data: dict):
    webhook_url = settings.WEBHOOK_URL
    payload = {
        "event": event,
        "data": data,
        "timestamp": datetime.utcnow().isoformat()
    }
    
    async with httpx.AsyncClient() as client:
        await client.post(webhook_url, json=payload)
```

## 🚀 Развертывание

### Docker Compose

**Production конфигурация:**
```yaml
version: '3.8'
services:
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/ssl
    depends_on:
      - frontend
      - backend

  frontend:
    build: ./frontend
    environment:
      - NODE_ENV=production
    deploy:
      replicas: 2

  backend:
    build: ./backend
    environment:
      - DATABASE_URL=postgresql://user:pass@postgres:5432/db
      - REDIS_URL=redis://redis:6379
    deploy:
      replicas: 3
    depends_on:
      - postgres
      - redis

  postgres:
    image: postgres:15
    environment:
      - POSTGRES_DB=inventory_db
      - POSTGRES_USER=inventory_user
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    deploy:
      resources:
        limits:
          memory: 2G

  redis:
    image: redis:7-alpine
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data

volumes:
  postgres_data:
  redis_data:
```

### CI/CD Pipeline

**GitHub Actions:**
```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run tests
        run: |
          docker-compose -f docker-compose.test.yml up --abort-on-container-exit
          
  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to server
        run: |
          ssh ${{ secrets.SERVER_HOST }} "
            cd /opt/inventory-system &&
            git pull origin main &&
            docker-compose down &&
            docker-compose up -d --build
          "
```

---

**Полезные ссылки:**
- [Главная страница проекта](https://github.com/ColinsWey/inventory-system)
- [API документация](API_DOCS.md)
- [Руководство по установке](INSTALL.md)
- [Руководство пользователя](USER_GUIDE.md) 